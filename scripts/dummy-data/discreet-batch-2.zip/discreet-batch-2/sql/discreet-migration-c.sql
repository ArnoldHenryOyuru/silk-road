-- Silk Road: discreet profiles, migration C (public homepage teaser)
-- Run once in Supabase > SQL Editor. Safe to re-run.
--
-- Returns the members who may appear on the public homepage, in random order.
-- A member qualifies only when ALL of these are true:
--   approved profile, active account, listed on Discover (is_discoverable),
--   homepage opt-in on (teaser_opt_in), and at least one approved photo.
-- It returns only first name, age, campus and the main photo's storage path:
-- no ids, no phone numbers, no bios.
--
-- Only the server (service role) can call it. Visitors' browsers cannot, so the
-- profiles table is never opened to anonymous reads.

create or replace function public.get_teaser_profiles(max_rows integer default 8)
returns table (first_name text, age integer, campus text, photo_path text)
language sql
stable
security definer
set search_path = public
as $$
  select
    split_part(btrim(p.display_name::text), ' ', 1)::text,
    p.age::integer,
    p.campus::text,
    ph.image_url::text
  from public.profiles p
  join public.users u on u.id = p.user_id
  join lateral (
    select pp.image_url
    from public.profile_photos pp
    where pp.profile_id = p.id
      and pp.status = 'approved'
    order by pp.is_primary desc, pp.created_at asc
    limit 1
  ) ph on true
  where p.status = 'approved'
    and u.status = 'active'
    and p.is_discoverable
    and p.teaser_opt_in
  order by random()
  limit least(greatest(max_rows, 1), 12);
$$;

revoke all on function public.get_teaser_profiles(integer) from public, anon, authenticated;
grant execute on function public.get_teaser_profiles(integer) to service_role;

-- Check (run after switching teaser_opt_in on for a few test profiles):
-- select * from public.get_teaser_profiles(8);
