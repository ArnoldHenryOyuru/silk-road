-- Silk Road: discreet profiles, migration B (column permissions)
-- Run once in Supabase > SQL Editor. Safe to re-run.
--
-- Your sql/lock-down-columns.sql stops members from writing protected columns
-- (like status). If it works by granting only specific columns, the two new
-- columns need the same permission or saving the signup / Edit Profile form will
-- fail with "permission denied". These grants only cover the two new columns and
-- change nothing for any other column.

grant insert (is_discoverable, teaser_opt_in) on public.profiles to authenticated;
grant update (is_discoverable, teaser_opt_in) on public.profiles to authenticated;
